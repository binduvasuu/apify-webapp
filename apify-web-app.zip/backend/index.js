const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/actors', async (req, res) => {
  try {
    const response = await axios.get('https://api.apify.com/v2/acts?limit=10&offset=0&origin=community');
    res.json(response.data);
  } catch (err) {
    console.error("Public actors error:", err.message);
    res.status(500).json({ error: 'Error fetching public actors' });
  }
});

app.listen(5000, () => console.log('✅ Backend running on port 5000'));